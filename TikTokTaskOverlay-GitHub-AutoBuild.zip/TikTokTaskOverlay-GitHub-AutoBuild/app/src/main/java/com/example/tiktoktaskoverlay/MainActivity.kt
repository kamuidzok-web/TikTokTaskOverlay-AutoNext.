package com.example.tiktoktaskoverlay

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tasks", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28)
            setBackgroundColor(Color.rgb(15,23,42))
        }
        fun edit(h:String)=EditText(this).apply{hint=h;setTextColor(Color.WHITE);setHintTextColor(Color.GRAY)}
        val title=TextView(this).apply{text="🎵 TikTok Task Overlay";textSize=24f;setTextColor(Color.WHITE)}
        val info=TextView(this).apply{
            text="Dán link/nội dung nhiệm vụ. Tool tự lấy @username. Bạn chỉ cần tự bấm Follow rồi xác nhận."
            setTextColor(Color.LTGRAY);setPadding(0,10,0,15)
        }
        val input=edit("Link hoặc nội dung nhiệm vụ TikTok")
        val reward=edit("Tiền thưởng (VNĐ)")
        val add=Button(this).apply{text="➕ Thêm nhiệm vụ"}
        val start=Button(this).apply{text="🚀 Bắt đầu / nhiệm vụ tiếp theo"}
        val overlay=Button(this).apply{text="⚙️ Bật cửa sổ nổi"}

        root.addView(title);root.addView(info);root.addView(input);root.addView(reward)
        root.addView(add);root.addView(start);root.addView(overlay)
        setContentView(root)

        add.setOnClickListener {
            val raw=input.text.toString().trim()
            val user=extractUsername(raw)
            if(user==null){Toast.makeText(this,"Không tìm thấy username TikTok.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            addTask(user,reward.text.toString().ifBlank{"0"})
            input.text.clear();reward.text.clear()
            Toast.makeText(this,"Đã thêm @$user vào hàng chờ.",Toast.LENGTH_SHORT).show()
        }

        start.setOnClickListener { startNext() }

        overlay.setOnClickListener {
            if(!Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            else Toast.makeText(this,"Cửa sổ nổi đã sẵn sàng.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun addTask(user:String,reward:String){
        val old=prefs.getString("queue","") ?: ""
        val item="$user|$reward"
        prefs.edit().putString("queue", if(old.isBlank()) item else "$old;;$item").apply()
    }

    fun startNext(){
        if(!Settings.canDrawOverlays(this)){
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            return
        }
        val q=(prefs.getString("queue","") ?: "").split(";;").filter{it.isNotBlank()}.toMutableList()
        if(q.isEmpty()){
            Toast.makeText(this,"Đã hết nhiệm vụ trong hàng chờ.",Toast.LENGTH_SHORT).show()
            return
        }
        val parts=q.removeAt(0).split("|",limit=2)
        prefs.edit().putString("queue",q.joinToString(";;")).apply()
        startService(Intent(this,OverlayService::class.java).apply{
            putExtra("username",parts[0]);putExtra("reward",parts.getOrElse(1){"0"})
        })
    }

    private fun extractUsername(raw:String):String?{
        val r=Regex("""(?:tiktok\.com/@|@)([A-Za-z0-9._]+)""",RegexOption.IGNORE_CASE)
        return r.find(raw)?.groupValues?.get(1)
    }
}
