package com.example.tiktoktaskoverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import android.graphics.PixelFormat

class OverlayService:Service(){
    private lateinit var wm:WindowManager
    private lateinit var view:View
    private var username=""
    private var reward="0"

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
        username=intent?.getStringExtra("username")?:""
        reward=intent?.getStringExtra("reward")?:"0"
        show()
        return START_STICKY
    }

    private fun show(){
        if(::view.isInitialized)try{wm.removeView(view)}catch(_:Exception){}
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(14,10,14,10)
            setBackgroundColor(Color.rgb(24,34,56))
        }
        val title=TextView(this).apply{text="🎯 Follow @$username";textSize=14f;setTextColor(Color.WHITE)}
        val money=TextView(this).apply{text="+${reward}đ";textSize=13f;setTextColor(Color.rgb(74,222,128))}
        val row=LinearLayout(this)
        val open=Button(this).apply{text="Mở TikTok";textSize=11f}
        val done=Button(this).apply{text="Đã Follow →";textSize=11f}
        val close=Button(this).apply{text="✕";textSize=11f}
        row.addView(open,LinearLayout.LayoutParams(0,-2,1f))
        row.addView(done,LinearLayout.LayoutParams(0,-2,1f))
        row.addView(close,LinearLayout.LayoutParams(0,-2,.55f))
        box.addView(title);box.addView(money);box.addView(row)

        open.setOnClickListener{
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.tiktok.com/@$username")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        done.setOnClickListener{
            // User manually performed Follow. Stop this overlay, then open the main app.
            stopSelf()
            val i=packageManager.getLaunchIntentForPackage(packageName)
            i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
            Toast.makeText(this,"Đã xác nhận. Hãy bấm 'Bắt đầu / nhiệm vụ tiếp theo'.",Toast.LENGTH_SHORT).show()
        }

        close.setOnClickListener{stopSelf()}
        view=box;wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val type=if(android.os.Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.END;p.x=10;p.y=90
        wm.addView(view,p)

        view.setOnTouchListener(object:View.OnTouchListener{
            var dx=0f;var dy=0f;var sx=0;var sy=0
            override fun onTouch(v:View,e:MotionEvent):Boolean{
                when(e.action){
                    MotionEvent.ACTION_DOWN->{dx=e.rawX;dy=e.rawY;sx=p.x;sy=p.y;return true}
                    MotionEvent.ACTION_MOVE->{p.x=sx+(dx-e.rawX).toInt();p.y=sy+(e.rawY-dy).toInt();wm.updateViewLayout(view,p);return true}
                };return false
            }
        })
    }

    override fun onDestroy(){if(::view.isInitialized)try{wm.removeView(view)}catch(_:Exception){};super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
