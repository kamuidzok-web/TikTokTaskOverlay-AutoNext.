# TikTokTaskOverlay - GitHub Auto Build

Project Android có sẵn GitHub Actions.

## Build APK trên GitHub

1. Upload **toàn bộ nội dung project** lên repository, giữ nguyên cấu trúc thư mục.
2. Mở tab **Actions**.
3. Chọn **Build Android APK**.
4. Nhấn **Run workflow** nếu workflow chưa tự chạy.
5. Khi build xong, mở lần chạy thành công và tải artifact **TikTokTaskOverlay-debug**.

Workflow nằm tại:
`.github/workflows/build.yml`

Lưu ý: ứng dụng chỉ hỗ trợ mở nhiệm vụ, cửa sổ nổi và chuyển sang nhiệm vụ tiếp theo. Người dùng tự bấm Follow.
